# Violet — Full-stack authentication mobile app

A purple-themed React Native app for Android and iOS built with Expo, Firebase Authentication, and Cloud Firestore.

## Features

- Email/password sign-up and login
- Google sign-in through Google OAuth and Firebase Authentication
- Email verification on email/password registration
- Password-reset email
- Persistent sign-in on mobile
- Firestore user profile creation and profile-name updates
- Per-user Firestore security rules
- Responsive login, registration, and signed-in profile screens

> This is a working starter project, not a published app. You must configure your own Firebase and Google OAuth project IDs before authentication will work. Never share service-account credentials or private keys in the app.

## 1. Requirements

- Node.js LTS
- npm
- Expo Go for initial UI testing (Google OAuth may require a development build)
- Android Studio for local Android builds, and/or Xcode on macOS for local iOS builds
- A Firebase project and a Google Cloud OAuth configuration

## 2. Install

Unzip the project, open a terminal in the project folder, then run:

```bash
npm install
cp .env.example .env
```

On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp`.

## 3. Configure Firebase

1. Open the Firebase Console and create a project.
2. In **Project settings → General**, register an app. Copy the Firebase web-app configuration values into `.env`.
3. In **Build → Authentication → Sign-in method**, enable **Email/Password** and **Google**.
4. Under Authentication settings, configure an authorized support email if requested.
5. In **Build → Firestore Database**, create a database. Choose a location appropriate for your users and data residency needs.
6. In Firestore → Rules, paste the contents of `firestore.rules` and publish them.
7. Fill in all `EXPO_PUBLIC_FIREBASE_*` values in `.env`. Expo public variables are bundled into the app; Firebase client configuration is not a server secret. Firestore Security Rules and Authentication are what protect user data.

Do not use a Firebase Admin SDK service-account JSON file in a mobile app. It would give the app privileged server access.

## 4. Configure Google sign-in

Google sign-in requires OAuth client IDs for the platforms you intend to build.

1. In Firebase Authentication, enable the Google provider and select a support email.
2. In Google Cloud Console, configure the OAuth consent screen.
3. Create OAuth 2.0 client IDs as appropriate:
   - **Web client ID** → `EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID`
   - **iOS client ID** → `EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID`
   - **Android client ID** → `EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID`
4. For Android, use the exact package ID from `app.json` (`com.yourcompany.violet` unless you change it) and register the SHA-1/SHA-256 fingerprints of your development/release signing certificates with Firebase/Google.
5. For iOS, use the exact bundle identifier from `app.json` and configure the matching iOS OAuth client.
6. Keep the same identifiers in Google Cloud and your Expo app configuration. If you change the package/bundle ID, update the OAuth clients too.

OAuth configuration and redirect handling can vary by Expo SDK and Google project setup. Test Google sign-in in a development build on each target platform, not only in Expo Go. If Google returns no ID token, check the client IDs, app identifiers, consent-screen test users, and redirect configuration.

## 5. Run the app

```bash
npx expo start
```

Scan the QR code with Expo Go to preview the interface. Email/password flows should work after Firebase configuration. Native Google OAuth may require the development build described below.

For a native development build:

```bash
npx expo install expo-dev-client
npx expo run:android
```

For iOS local builds, use a Mac with Xcode:

```bash
npx expo run:ios
```

You can also use EAS Build to create cloud builds. Install and configure EAS CLI, then follow Expo's current build instructions for Android and iOS. For iOS distribution, Apple Developer account requirements apply.

## 6. Security notes

- Firestore rules deny access by default and allow a user to read/update only `/users/{their-uid}`.
- User profile documents contain only basic profile fields. Do not store passwords in Firestore.
- Firebase client configuration and `EXPO_PUBLIC_*` values are visible in the app bundle. Do not put private keys, admin credentials, or service-account files in them.
- Never deploy permissive rules such as `allow read, write: if true`.
- Consider enabling Firebase App Check for supported services before production release.
- Set password policy and email-enumeration protection in Firebase Authentication settings where available.
- Configure authorized domains and OAuth consent-screen test users appropriately.
- For a production application, add automated tests, error monitoring, privacy policy, account deletion workflow, and abuse/rate-limit controls where applicable.

## 7. Troubleshooting

- **`auth/operation-not-allowed`**: enable Email/Password or Google in Firebase Authentication.
- **Permission denied in Firestore**: publish `firestore.rules`; ensure the user is signed in and the document ID equals their Firebase UID.
- **Google sign-in has no ID token**: verify all OAuth client IDs, package/bundle IDs, SHA fingerprints, and redirect settings; test with a development build.
- **Firebase config warning**: make sure `.env` exists and every Firebase value is filled in; restart Expo after changing environment variables.
- **Android/iOS build error**: confirm Node and Expo dependencies are installed and follow the current Expo SDK platform setup documentation.

## Project structure

```text
App.tsx                UI and app state
src/firebase.ts        Firebase initialization and persistent Auth
src/auth.ts            Email, Google, reset-password, profile helpers
firestore.rules        User-owned Firestore security rules
app.json               Expo app identity and native identifiers
.env.example           Environment variable template
```
