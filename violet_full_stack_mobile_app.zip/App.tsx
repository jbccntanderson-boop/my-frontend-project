import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as WebBrowser from "expo-web-browser";
import * as Google from "expo-auth-session/providers/google";
import { ResponseType } from "expo-auth-session";
import { onAuthStateChanged, User } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import { auth, db } from "./src/firebase";
import {
  loginWithEmail,
  loginWithGoogleIdToken,
  logout,
  registerWithEmail,
  resetPassword,
  saveDisplayName,
} from "./src/auth";

WebBrowser.maybeCompleteAuthSession();

type Mode = "login" | "signup";
type Profile = { displayName?: string; email?: string; provider?: string };

const PURPLE = "#6D28D9";
const DEEP = "#4C1D95";
const PALE = "#F5F0FF";
const INK = "#211638";
const MUTED = "#776D89";

function Button({
  title,
  onPress,
  loading = false,
  secondary = false,
}: {
  title: string;
  onPress: () => void;
  loading?: boolean;
  secondary?: boolean;
}) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      activeOpacity={0.85}
      disabled={loading}
      onPress={onPress}
      style={[styles.button, secondary && styles.secondaryButton, loading && { opacity: 0.7 }]}
    >
      {loading ? (
        <ActivityIndicator color={secondary ? PURPLE : "#FFFFFF"} />
      ) : (
        <Text style={[styles.buttonText, secondary && styles.secondaryButtonText]}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  secureTextEntry,
  keyboardType,
  autoCapitalize = "none",
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  secureTextEntry?: boolean;
  keyboardType?: "default" | "email-address";
  autoCapitalize?: "none" | "words";
}) {
  const [visible, setVisible] = useState(false);
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.inputShell}>
        <TextInput
          accessibilityLabel={label}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          keyboardType={keyboardType ?? "default"}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#A59AB7"
          secureTextEntry={secureTextEntry && !visible}
          style={styles.input}
          value={value}
          textContentType={label === "Password" ? "password" : label === "Email address" ? "emailAddress" : "none"}
        />
        {secureTextEntry ? (
          <TouchableOpacity onPress={() => setVisible((v) => !v)} style={styles.eyeButton}>
            <Text style={styles.eyeText}>{visible ? "Hide" : "Show"}</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </View>
  );
}

export default function App() {
  const [mode, setMode] = useState<Mode>("signup");
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile>({});
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [profileBusy, setProfileBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [googleRequest, googleResponse, promptGoogle] = Google.useAuthRequest({
    webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
    iosClientId: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
    androidClientId: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID,
    responseType: ResponseType.IdToken,
    scopes: ["openid", "profile", "email"],
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      if (!nextUser) setProfile({});
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    const finishGoogle = async () => {
      if (googleResponse?.type !== "success") return;
      const idToken =
        googleResponse.params?.id_token ??
        googleResponse.authentication?.idToken;
      const accessToken = googleResponse.authentication?.accessToken;
      if (!idToken) {
        Alert.alert(
          "Google sign-in setup",
          "No ID token was returned. Check your Google OAuth client IDs and redirect configuration."
        );
        return;
      }
      setBusy(true);
      try {
        await loginWithGoogleIdToken(idToken, accessToken);
        setNotice("You're signed in with Google.");
      } catch (error) {
        Alert.alert("Google sign-in failed", (error as Error).message);
      } finally {
        setBusy(false);
      }
    };
    void finishGoogle();
  }, [googleResponse]);

  useEffect(() => {
    const loadProfile = async () => {
      if (!user) return;
      try {
        const snapshot = await getDoc(doc(db, "users", user.uid));
        if (snapshot.exists()) setProfile(snapshot.data() as Profile);
        else setProfile({ displayName: user.displayName ?? "", email: user.email ?? "" });
      } catch {
        setProfile({ displayName: user.displayName ?? "", email: user.email ?? "" });
      }
    };
    void loadProfile();
  }, [user]);

  const greetingName = useMemo(
    () => profile.displayName || user?.displayName || user?.email?.split("@")[0] || "there",
    [profile.displayName, user]
  );

  const validate = () => {
    if (!email.trim()) return "Please enter your email address.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return "Please enter a valid email address.";
    if (mode === "signup" && !name.trim()) return "Please enter your name.";
    if (!password) return "Please enter your password.";
    if (mode === "signup" && password.length < 8) return "Use a password with at least 8 characters.";
    return "";
  };

  const submit = async () => {
    const error = validate();
    if (error) {
      Alert.alert("Check your details", error);
      return;
    }
    setBusy(true);
    setNotice("");
    try {
      if (mode === "signup") {
        await registerWithEmail(name, email, password);
        setNotice("Account created. Check your inbox for the verification email.");
      } else {
        await loginWithEmail(email, password);
        setNotice("Welcome back!");
      }
    } catch (error) {
      Alert.alert(mode === "signup" ? "Could not create account" : "Could not sign in", (error as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleReset = async () => {
    if (!email.trim()) {
      Alert.alert("Password reset", "Enter your email address first.");
      return;
    }
    setBusy(true);
    try {
      await resetPassword(email);
      Alert.alert("Check your email", "If an account exists for this address, a password-reset email has been sent.");
    } catch (error) {
      Alert.alert("Could not send reset email", (error as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setProfileBusy(true);
    try {
      await saveDisplayName(user.uid, name || profile.displayName || user.displayName || "");
      setProfile((p) => ({ ...p, displayName: (name || profile.displayName || user.displayName || "").trim() }));
      setName("");
      Alert.alert("Profile updated", "Your display name has been saved.");
    } catch (error) {
      Alert.alert("Could not update profile", (error as Error).message);
    } finally {
      setProfileBusy(false);
    }
  };

  if (user) {
    return (
      <SafeAreaView style={styles.safe}>
        <ExpoStatusBar style="light" backgroundColor={DEEP} />
        <ScrollView contentContainerStyle={styles.dashboardScroll}>
          <View style={styles.dashboardHero}>
            <View style={styles.brandMark}><Text style={styles.brandMarkText}>V</Text></View>
            <Text style={styles.dashboardEyebrow}>YOUR PERSONAL SPACE</Text>
            <Text style={styles.dashboardTitle}>Hello, {greetingName}!</Text>
            <Text style={styles.dashboardSubtitle}>You’re signed in. Your next chapter starts here.</Text>
          </View>
          <View style={styles.profileCard}>
            <Text style={styles.cardEyebrow}>ACCOUNT</Text>
            <Text style={styles.profileName}>{user.displayName || profile.displayName || "Violet member"}</Text>
            <Text style={styles.profileEmail}>{user.email || "Google account"}</Text>
            <View style={styles.statusPill}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>{user.emailVerified ? "Email verified" : "Signed in"}</Text>
            </View>
            {!user.emailVerified && user.providerData.some((p) => p.providerId === "password") ? (
              <Text style={styles.smallHint}>Please check your inbox for the verification link.</Text>
            ) : null}
            <View style={styles.divider} />
            <Text style={styles.label}>Update your display name</Text>
            <TextInput
              onChangeText={setName}
              placeholder={profile.displayName || user.displayName || "Your name"}
              placeholderTextColor="#A59AB7"
              style={styles.profileInput}
              value={name}
            />
            <Button title="Save profile" onPress={handleSaveProfile} loading={profileBusy} />
            {notice ? <Text style={styles.notice}>{notice}</Text> : null}
          </View>
          <Button title="Sign out" onPress={() => void logout()} secondary />
          <Text style={styles.footer}>VIOLET · MADE FOR A FRESH START</Text>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ExpoStatusBar style="light" backgroundColor={DEEP} />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.flex}
      >
        <ScrollView
          contentContainerStyle={styles.authScroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.hero}>
            <View style={styles.decor decorOne} />
            <View style={styles.decor decorTwo} />
            <View style={styles.brandMark}><Text style={styles.brandMarkText}>V</Text></View>
            <Text style={styles.eyebrow}>WELCOME TO VIOLET</Text>
            <Text style={styles.heroTitle}>{mode === "signup" ? "Create your\nown space." : "Welcome\nback."}</Text>
            <Text style={styles.heroSubtitle}>
              {mode === "signup" ? "A little space for your next big thing." : "Your space is ready when you are."}
            </Text>
          </View>

          <View style={styles.formCard}>
            <View style={styles.modeSwitch}>
              <TouchableOpacity onPress={() => { setMode("login"); setNotice(""); }} style={[styles.modeOption, mode === "login" && styles.modeActive]}>
                <Text style={[styles.modeText, mode === "login" && styles.modeTextActive]}>Log in</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => { setMode("signup"); setNotice(""); }} style={[styles.modeOption, mode === "signup" && styles.modeActive]}>
                <Text style={[styles.modeText, mode === "signup" && styles.modeTextActive]}>Sign up</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.formTitle}>{mode === "signup" ? "Let’s get you started" : "Good to see you again"}</Text>
            <Text style={styles.formSubtitle}>
              {mode === "signup" ? "Create an account in just a moment." : "Enter your details to continue."}
            </Text>

            {mode === "signup" ? (
              <Field label="Full name" value={name} onChangeText={setName} placeholder="Your full name" autoCapitalize="words" />
            ) : null}
            <Field label="Email address" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" />
            <Field label="Password" value={password} onChangeText={setPassword} placeholder={mode === "signup" ? "At least 8 characters" : "Enter your password"} secureTextEntry />

            {mode === "login" ? (
              <TouchableOpacity onPress={() => void handleReset()} style={styles.forgotButton}>
                <Text style={styles.forgotText}>Forgot password?</Text>
              </TouchableOpacity>
            ) : (
              <Text style={styles.helperText}>Use at least 8 characters for your password.</Text>
            )}

            <Button title={mode === "signup" ? "Create account  →" : "Log in  →"} onPress={() => void submit()} loading={busy} />

            <View style={styles.orRow}>
              <View style={styles.orLine} /><Text style={styles.orText}>OR CONTINUE WITH</Text><View style={styles.orLine} />
            </View>
            <Button
              title="G   Continue with Google"
              secondary
              loading={busy}
              onPress={() => {
                if (!googleRequest) {
                  Alert.alert("Please wait", "Google sign-in is preparing.");
                  return;
                }
                void promptGoogle();
              }}
            />
            {notice ? <Text style={styles.notice}>{notice}</Text> : null}
            <Text style={styles.terms}>
              By continuing, you agree to use Violet responsibly. Your account information is protected by Firebase Authentication.
            </Text>
          </View>
          <Text style={styles.footer}>VIOLET · YOUR NEXT CHAPTER STARTS HERE</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: DEEP },
  flex: { flex: 1 },
  authScroll: { flexGrow: 1, backgroundColor: "#F8F6FC", paddingBottom: 24 },
  hero: { backgroundColor: DEEP, minHeight: 285, paddingTop: 24, paddingHorizontal: 28, paddingBottom: 56, overflow: "hidden" },
  decor: { position: "absolute", borderRadius: 999, backgroundColor: "#7C3AED", opacity: 0.22 },
  decorOne: { width: 230, height: 230, top: -105, right: -45 },
  decorTwo: { width: 155, height: 155, bottom: -75, left: -35 },
  brandMark: { width: 48, height: 48, borderRadius: 16, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", marginBottom: 24 },
  brandMarkText: { color: PURPLE, fontSize: 27, fontWeight: "900" },
  eyebrow: { color: "#D9C8FF", fontSize: 10, letterSpacing: 2.5, fontWeight: "800", marginBottom: 12 },
  heroTitle: { color: "#FFFFFF", fontSize: 38, lineHeight: 42, fontWeight: "800", letterSpacing: -1.2 },
  heroSubtitle: { color: "#E6DDFB", fontSize: 14, marginTop: 12, lineHeight: 21 },
  formCard: { backgroundColor: "#FFFFFF", marginTop: -28, marginHorizontal: 16, borderRadius: 26, padding: 22, shadowColor: "#2E1457", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.09, shadowRadius: 22, elevation: 5 },
  modeSwitch: { flexDirection: "row", backgroundColor: "#F3EFFA", borderRadius: 14, padding: 4, marginBottom: 24 },
  modeOption: { flex: 1, paddingVertical: 11, borderRadius: 11, alignItems: "center" },
  modeActive: { backgroundColor: "#FFFFFF", shadowColor: "#2E1457", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 2 },
  modeText: { color: MUTED, fontSize: 14, fontWeight: "700" },
  modeTextActive: { color: PURPLE },
  formTitle: { color: INK, fontSize: 23, fontWeight: "800", letterSpacing: -0.5 },
  formSubtitle: { color: MUTED, fontSize: 13, marginTop: 6, marginBottom: 20 },
  fieldWrap: { marginBottom: 15 },
  label: { color: INK, fontSize: 12, fontWeight: "700", marginBottom: 8 },
  inputShell: { minHeight: 52, borderWidth: 1, borderColor: "#E7E0F0", backgroundColor: "#FCFBFE", borderRadius: 13, flexDirection: "row", alignItems: "center", paddingHorizontal: 14 },
  input: { flex: 1, color: INK, fontSize: 14, paddingVertical: 13 },
  eyeButton: { paddingLeft: 8, paddingVertical: 8 },
  eyeText: { color: PURPLE, fontSize: 12, fontWeight: "800" },
  forgotButton: { alignSelf: "flex-end", marginTop: -4, marginBottom: 18 },
  forgotText: { color: PURPLE, fontSize: 12, fontWeight: "700" },
  helperText: { color: MUTED, fontSize: 11, marginTop: -5, marginBottom: 16 },
  button: { minHeight: 52, backgroundColor: PURPLE, borderRadius: 14, alignItems: "center", justifyContent: "center", paddingHorizontal: 16, marginTop: 4 },
  buttonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
  secondaryButton: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E4D9F7" },
  secondaryButtonText: { color: DEEP },
  orRow: { flexDirection: "row", alignItems: "center", gap: 10, marginVertical: 20 },
  orLine: { flex: 1, height: 1, backgroundColor: "#EEE8F5" },
  orText: { color: "#9B91AA", fontSize: 9, fontWeight: "800", letterSpacing: 1.3 },
  terms: { color: "#9B91AA", fontSize: 10, lineHeight: 16, textAlign: "center", marginTop: 18 },
  notice: { color: DEEP, backgroundColor: PALE, borderRadius: 10, padding: 10, fontSize: 12, lineHeight: 18, marginTop: 12 },
  footer: { color: "#A49AB3", textAlign: "center", fontSize: 9, fontWeight: "800", letterSpacing: 1.5, marginTop: 22, marginHorizontal: 20 },
  dashboardScroll: { flexGrow: 1, backgroundColor: "#F8F6FC", paddingBottom: 28 },
  dashboardHero: { backgroundColor: DEEP, paddingTop: 30, paddingHorizontal: 26, paddingBottom: 58 },
  dashboardEyebrow: { color: "#D9C8FF", fontSize: 10, letterSpacing: 2, fontWeight: "800", marginBottom: 12 },
  dashboardTitle: { color: "#FFFFFF", fontSize: 30, fontWeight: "800", letterSpacing: -0.7 },
  dashboardSubtitle: { color: "#E6DDFB", fontSize: 13, lineHeight: 20, marginTop: 9 },
  profileCard: { marginTop: -28, marginHorizontal: 16, backgroundColor: "#FFFFFF", borderRadius: 24, padding: 22, shadowColor: "#2E1457", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.08, shadowRadius: 20, elevation: 4 },
  cardEyebrow: { color: "#8D7DA7", fontSize: 10, letterSpacing: 1.8, fontWeight: "800", marginBottom: 10 },
  profileName: { color: INK, fontSize: 22, fontWeight: "800" },
  profileEmail: { color: MUTED, fontSize: 13, marginTop: 5 },
  statusPill: { flexDirection: "row", alignItems: "center", alignSelf: "flex-start", backgroundColor: "#F0EAFB", borderRadius: 99, paddingVertical: 7, paddingHorizontal: 10, marginTop: 15 },
  statusDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#7C3AED", marginRight: 7 },
  statusText: { color: DEEP, fontSize: 11, fontWeight: "700" },
  smallHint: { color: MUTED, fontSize: 11, marginTop: 10, lineHeight: 17 },
  divider: { height: 1, backgroundColor: "#EEE8F5", marginVertical: 22 },
  profileInput: { minHeight: 50, borderWidth: 1, borderColor: "#E7E0F0", backgroundColor: "#FCFBFE", borderRadius: 13, paddingHorizontal: 14, color: INK, marginBottom: 12 },
});
