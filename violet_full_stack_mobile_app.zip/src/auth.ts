import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  User,
  GoogleAuthProvider,
  signInWithCredential,
} from "firebase/auth";
import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
  updateDoc,
} from "firebase/firestore";
import { auth, db } from "./firebase";

function friendlyError(error: unknown): string {
  const code = (error as { code?: string })?.code;
  const messages: Record<string, string> = {
    "auth/email-already-in-use": "An account with this email already exists.",
    "auth/invalid-email": "Enter a valid email address.",
    "auth/weak-password": "Choose a stronger password (at least 8 characters).",
    "auth/invalid-credential": "The email or password is incorrect.",
    "auth/user-disabled": "This account has been disabled.",
    "auth/too-many-requests": "Too many attempts. Please wait a little and try again.",
    "auth/network-request-failed": "Network error. Check your internet connection.",
    "auth/popup-closed-by-user": "Google sign-in was cancelled.",
    "auth/account-exists-with-different-credential":
      "An account already exists with this email using another sign-in method.",
  };
  return (code && messages[code]) || (error instanceof Error ? error.message : "Something went wrong.");
}

async function ensureUserProfile(user: User, name?: string) {
  const ref = doc(db, "users", user.uid);
  const existing = await getDoc(ref);
  const displayName = name?.trim() || user.displayName || "";
  if (!existing.exists()) {
    await setDoc(ref, {
      uid: user.uid,
      email: user.email ?? "",
      displayName,
      photoURL: user.photoURL ?? null,
      provider: user.providerData[0]?.providerId ?? "password",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } else {
    await updateDoc(ref, {
      email: user.email ?? "",
      displayName,
      photoURL: user.photoURL ?? null,
      updatedAt: serverTimestamp(),
    });
  }
}

export async function registerWithEmail(name: string, email: string, password: string) {
  try {
    const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
    if (name.trim()) await updateProfile(credential.user, { displayName: name.trim() });
    await ensureUserProfile(credential.user, name);
    await sendEmailVerification(credential.user);
    return credential.user;
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}

export async function loginWithEmail(email: string, password: string) {
  try {
    const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
    await ensureUserProfile(credential.user);
    return credential.user;
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}

export async function loginWithGoogleIdToken(idToken: string, accessToken?: string) {
  try {
    const credential = GoogleAuthProvider.credential(idToken, accessToken);
    const result = await signInWithCredential(auth, credential);
    await ensureUserProfile(result.user);
    return result.user;
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}

export async function resetPassword(email: string) {
  try {
    await sendPasswordResetEmail(auth, email.trim());
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}

export async function logout() {
  await signOut(auth);
}

export async function saveDisplayName(uid: string, displayName: string) {
  const cleanName = displayName.trim();
  if (!cleanName) throw new Error("Name cannot be empty.");
  if (auth.currentUser?.uid !== uid) throw new Error("You can only update your own profile.");
  await updateProfile(auth.currentUser, { displayName: cleanName });
  await updateDoc(doc(db, "users", uid), {
    displayName: cleanName,
    updatedAt: serverTimestamp(),
  });
}

export { friendlyError };
